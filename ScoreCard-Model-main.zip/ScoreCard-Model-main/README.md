# ScoreCard-Model
Final Project at Home Credit Indonesia Data Scientist Project Based Internship Program
